package com.gfviegas.ex3;

public abstract class Forma {
    abstract float calcularArea();

    abstract float cacularPerimetro();

    abstract String getTipo();
}

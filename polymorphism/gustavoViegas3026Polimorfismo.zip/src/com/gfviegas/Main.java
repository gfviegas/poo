package com.gfviegas;

public class Main {

    public static void main(String[] args) {
        System.out.println("\n\tExercicio 1: \n");
        com.gfviegas.ex1.Main.main(args);

        System.out.println("\n\tExercicio 2: \n Nada a imprimir. \n");

        System.out.println("\n\tExercicio 3: \n");
        com.gfviegas.ex3.Main.main(args);

        System.out.println("\n\tExercicio 4: \n");
        com.gfviegas.ex4.Main.main(args);
    }
}

package com.gfviegas.ex4;

public interface Objeto {
    public boolean verificaVitoria(Objeto adversario);
}

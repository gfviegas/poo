package com.gfviegas.ex4;

public class Main {

    public static void main(String[] args) {
        Jogo jogo = new Jogo();
        jogo.joga();
    }
}

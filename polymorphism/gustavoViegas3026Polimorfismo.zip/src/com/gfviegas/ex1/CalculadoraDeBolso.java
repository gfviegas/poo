package com.gfviegas.ex1;

public class CalculadoraDeBolso extends Calculadora {
    final static String name = "Calculadora de Bolso Pequena CC1000";
}
